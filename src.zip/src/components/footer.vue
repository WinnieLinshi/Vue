<template>
  <Footer class="layout-footer-center">2020 &copy; Winnie</Footer>
</template>

<style scoped>
.layout-footer-center {
  text-align: center;
}
</style>