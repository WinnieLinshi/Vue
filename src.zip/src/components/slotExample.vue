<template>
  <a v-bind:href="url" class="nav-link">
    <slot></slot>
  </a>
</template>