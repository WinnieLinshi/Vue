<template>
  <div class="about">
    <h1>命名衝突</h1>
    中括號的調用：{{ test }}
    <br />
    <button @click="test">＠click的調用：因命名衝突沒作用!</button>
    <br />
    <img src="../assets/bug.png" />
    <br />
    <br />
    <br />
    <h1>slot</h1>
    <slotExample>I'm a easy slot Example!</slotExample>
    <br />
    <br />
    <br />
    <h1>Vuex</h1>
    <p>search和文章取值使用</p>
    <img src="../assets/vuex.png"/>
    <br />
    <br />
    <br />
    <h1>權限管理方式</h1>
<p><a href="https://codertw.com/%E7%A8%8B%E5%BC%8F%E8%AA%9E%E8%A8%80/672731/#outline__1_1">權限管理詳情參考</a></p>
    <img src="../assets/auth.png"/>
  </div>
</template>
<style scoped>
img:hover {
  transform: scale(3, 3);
  transition: all 0.3s ease 0s;
}
img {
  transform: scale(1, 1);
  transition: all 0.5s ease-out;
  width:300px;
}
div {
  text-align: center;
}
body {
  background-image: url("../assets/about.png");
}
</style>
<script>
import slotExample from "@/components/slotExample";
export default {
  data() {
    return {
      test: "顯示了data的值"
    };
  },
  methods: {
    test: function() {
      alert("hi");
    }
  },
  components: {
    slotExample
  }
};
</script>