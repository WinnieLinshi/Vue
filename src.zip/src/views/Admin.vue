<template>
  <div class="Admin">
    <Tabs value="name1">
      <TabPane label="管理主頁" name="name1">
        <Table :columns="columns1" :data="articles"></Table>
      </TabPane>
      <TabPane label="新增文章" name="name2">
        <add></add>
        </TabPane>
      <TabPane label="标签三" name="name3">标签三的内容</TabPane>
    </Tabs>
  </div>
</template>
<script>
import add from "@/views/admin/Add";
import { mapState } from "vuex";
export default {
  data() {
    return {
      columns1: [
        {
          title: "ID",
          key: "id",
          width: "200"
        },
        {
          title: "Title",
          key: "title",
          width: "350",
          render: (h, params) => {
            return h("div", [h("strong", params.row.title)]);
          }
        },
        {
          title: "Content",
          key: "content",
          width: "800",
          render: (h, params) => {
            return h("div", [
              h(
                "p",
                params.row.content.substring(0, 100).replace(/<br>/g, "") +
                  "..."
              )
            ]);
          }
        },
        {
          title: "Date",
          key: "date",
          width: "400",
          render: (h, params) => {
            return h("div", [h("p", Date(params.row.date))]);
          }
        },
        {
          title: "Manage",
          key: "manage",
          render: (h, params) => {
            return h("div", [
              h(
                "Button",
                {
                  props: {
                    type: "primary",
                    size: "small"
                  },
                  style: {
                    marginRight: "5px"
                  },
                  on: {
                    click: () => {
                      this.show(params.index);
                    }
                  }
                },
                "View"
              ),
              h(
                "Button",
                {
                  props: {
                    type: "success",
                    size: "small"
                  },
                  style: {
                    marginRight: "5px"
                  },
                  on: {
                    click: () => {
                      this.routerToEdit(params.row.id);
                    }
                  }
                },
                "Edit"
              ),
              h(
                "Button",
                {
                  props: {
                    type: "error",
                    size: "small"
                  },
                  on: {
                    click: () => {
                      this.remove(params.index);
                    }
                  }
                },
                "Delete"
              )
            ]);
          }
        }
      ]
    };
  },
  components: {
    add
  },
  computed: {
    ...mapState(["articles"])
  },
  methods: {
    show(index) {
      this.$Modal.info({
        title: "Whole Content",
        closable: "true",
        content: `<b>Content：</b><br>${this.articles[index].content}`,
        width: "100%"
      });
    },
    remove(index) {
      this.articles.splice(index, 1);
    },
    routerToEdit: function(id) {
      this.$router.push({ name: "Admin-Edit", params: { id: id } });
    }
  }
};
</script>
