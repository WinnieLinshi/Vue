<template>
  <Form ref="formValidata" :model="formValidata" :rules="ruleValidate" :label-width="80">
    <FormItem label="Title" prop="title">
      <Input v-model="formValidata.title" placeholder="Enter your title"></Input>
    </FormItem>
    <FormItem label="Content" prop="content">
      <Input
        v-model="formValidata.content"
        type="textarea"
        :autosize="{minRows: 2,maxRows: 60}"
        placeholder="Enter something..."
      ></Input>
    </FormItem>
    <FormItem>
      <Button type="primary" @click="handleSubmit('formValidata')">Submit</Button>
      <Button @click="handleReset('formValidata')" style="margin-left: 8px">Reset</Button>
    </FormItem>
  </Form>
</template>
<script>
import { mapActions } from "vuex"
export default {

  data() {
    return {
      formValidata: {
        title: "",
        content: "",
        date: ""
      },
      ruleValidate: {
        title: [
          {
            required: true,
            message: "The title cannot be empty",
            trigger: "blur"
          }
        ],
        content: [
          {
            required: true,
            message: "Please enter article content!",
            trigger: "blur"
          },
          {
            type: "string",
            min: 20,
            message: "Content no less than 20 words",
            trigger: "blur"
          }
        ]
      }
    };
  },
  methods: {
    ...mapActions(['addArticle']),
    handleSubmit(formValidata) {
      this.$refs[formValidata].validate(valid => {
        if (valid) {
          this.formValidata.date = new Date().getTime();
          this.$Message.success("Success!");
          this.addArticle(this.formValidata);
        } else {
          this.$Message.error("Fail!");
        }
      });
    },
    handleReset(formValidata) {
      this.$refs[formValidata].resetFields();
    }
  }
};
</script>
